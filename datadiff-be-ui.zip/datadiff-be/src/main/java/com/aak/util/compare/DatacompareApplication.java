package com.aak.util.compare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatacompareApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatacompareApplication.class, args);
	}

}
